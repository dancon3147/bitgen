# BitGen
Next-generation digital gold blockchain.